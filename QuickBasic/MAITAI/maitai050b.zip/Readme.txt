Hitchhiker's Guide to MaiTAI games
--------------------------------------------
MaiTAI copyright 2008 Electrokinesis Studios
--------------------------------------------
Contents:
1.What the heck is MaiTAI?
2.So how do I program it?
  2.1.Main file
  2.2.Rooms
3. Changelog
4. Credits

--------------------------------------------
1. What the heck is MaiTAI?
   The clever ones probabl already said "duh, it's a drink."
If you're one of these, congratulations, you can recognize names.
   But no, MaiTAI is a pun on the drink's name, but it's not
drinkable. (WARNING: THE CREATOR OF THIS PROGRAM IS NOT RESPONSIBLE
IF YOU TRY TO SAVE MAITAI INTO A FLOPPY DISK, GRIND IT TO FINE POWDER,
MIX IT WITH WATER OR ANY OTHER FLUID AND DRINK IT.) MaiTAI instead
is, as the name also suggests, a Text Adventure Interpreter.
   That means you can easily make text adventure games with this
program.

--------------------------------------------
2. So how do I program it?
   it's simple. MaiTAI uses a BASIc-alike programming method, so you
can just grab your prefered text editor (EDIT, Notepad, Wordpad,
vi, emacs, whatever.) and start coding.

--------------------------------------------
2.1. Main file
     The main file is what sends all the general information such
as names to the interpreter. It should be located at
"(MaiTAI root directory)\(name of game, up to 8 chars)\INT.TAI".
     Here's a breakdown of the structure of the main file:

     [MAITAI] - Header: It's what MaiTAI uses to recognize the files.
     #hi - You can have comments on separate lines starting with #.
     The Average Adventures of Eric - Full name of the game.
     bedroom - First room's filename, sans .RM
     Eric -Character 's name
     200 - Game's maximum score

--------------------------------------------
2.2. Rooms - Upper half
     The rooms are coded just like the main files. They should be
located at (MaiTAI)\(game)\(room name, 8 chars).RM
     Here's the structure:

     [MAITAI ROOM] - Header.
     Bedroom - Full title of room.
     &DESC - Start of description.
     You see your bedroom. - Description, can be as long as you like.
        (NOTE: If the description is too big for the whole screen,
         use %S to make a pause on a certain point, then continue.)
     %I DISK - Checks for if the player has said item
     You see a disk here. -...and prints the line right after it.
     %H - End of desc. Alternatively, %P (room filename sans .RM) if
          the room was purely informative, then skips to another. In
          that case, anything after this is not needed.

     [ACTION] - Marks the start of the actions section.
     @SAY - The action the player should type.
     SAY Woo! - Statement, or "consequence".
     END - End of action.

     @GET 1 POINT - rinse and repeat
     SCORE 1 - Another statement.
     SAY WORKS!
     END

     @GET DISK -ditto
     ITEM DISK - Adds an item to the inventory...
     You got mail! I mean, disk. -...announces it if you get it
     You already have that. -...or if you already had it
        (NOTE: These lines must be right after the first ITEMSAY one, or
         it won't work. Comment lines are OK though, as they are entirely
         skipped by the line parser.)
     END

     @DROP DISK
     RMITEM DISK
     You dropped the disk. - RMITEM also displays the following line, if
                             the player has said item.
     END

     Here's a list of statements:
     SAY (string of text) - prints said string.
     SCORE (number) - Adds said number to the score.
     ITEM (item) - Already explained in the file structure.
     RMITEM (item) - Removes a certain item from inventory.
     CHKITEM (0-1) (item) - Checks if item is on the inventory (1) or not (0),
                            and runs the following line accordingly.
     WAIT - Waits for user to press any key (useful for pauses between SAY
            statements or before GOTOs, if you have printed something before).
     GOTO - (room filename, sans .RM) Warps player to said room.

--------------------------------------------
4. Changelog
   v0.35a - First revision
   v0.35b - Minor bugfixes
   v0.40b - More bugfixes, new statement "CHKITEM"
   v0.50b - Added "SAVE" and "LOAD" on main gameplay.
   
--------------------------------------------
4. Credits
   MaiTAI is copyright 2008 Electrokinesis Studios
   Visit us at electrokinesis.blogspot.com

   Programmer.........................................Eric P. Manal
   Idea-giving guy...........................................Chwoka
   Original concept...................................Eric P. Manal
   New concepts..............................................Chwoka

Contact:
   Eric P. Manal.............................cool_eric94@hotmail.com

--------------------------------------------------------------------------------

